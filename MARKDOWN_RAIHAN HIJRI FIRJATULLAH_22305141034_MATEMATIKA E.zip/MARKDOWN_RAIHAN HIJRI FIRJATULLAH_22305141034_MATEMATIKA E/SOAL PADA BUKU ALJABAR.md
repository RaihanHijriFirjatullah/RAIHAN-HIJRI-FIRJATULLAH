﻿# LATIHAN SOAL 
Nama : RAIHAN HIJRI FIRJATULLAH


Kelas : Matematika E


NIM : 22305141034


---

Pilih minimal 5 soal dari setiap Latihan atau tipe soal (misalnya
diantara soal-soal yang sudah saya blok). Jangan lupa tuliskan soalnya
di teks komentar (dengan format LaTeX) dan beri penjelasan hasil
output-nya. Ubah file notebook pekerjaan Anda menjadi file PDF
menggunakan salah satu metode di atas.


---

# R.2 Exercise set 

Soal No 49 Menyederhanakan:


\>$&((24\*a^(10)\*b^(-8)\*c^7)/(12\*a^6\*b^(-3)\*c^5))^(-5)


$$\frac{b^{25}}{32\,a^{20}\,c^{10}}$$Soal No 50


Menyederhanakan:


\>$&((125\*p^(12)\*q^(-14)\*r^(22))/25\*p^8\*q^6\*r^(-15))^(-4)


$$\frac{q^{32}}{625\,p^{80}\,r^{28}}$$Soal No 90


calculate


\>2^6\*2^-3/2^10/2^-8


    2

Soal No 91


Calculate


\>(4\*(8-6)^2 - 4\*3 + 2\*8)/(3^1+19^0)


    5

Soal No 92


Calculate


\>((4\*(8-6)^2-4)\*3+2\*8)/(3^1+9^0)


    13

# R.3 Exercise Set

Perform the indicated operations.


no 27


\>$&showev('expand((x+3)^2))


$${\it expand}\left(\left(x+3\right)^2\right)=x^2+6\,x+9$$no 29


\>$&showev('expand((y-5)^2))


$${\it expand}\left(\left(y-5\right)^2\right)=y^2-10\,y+25$$no 33


\>$&showev('expand((2\*x+3\*y)^2))


$${\it expand}\left(\left(3\,y+2\,x\right)^2\right)=9\,y^2+12\,x\,y+4  \,x^2$$no 39


\>$&showev('expand((3\*y+4)\*(3\*y-4)))


$${\it expand}\left(\left(3\,y-4\right)\,\left(3\,y+4\right)\right)=9  \,y^2-16$$no 42


\>$&showev('expand ((3\*x + 5\*y)\*(3\*x - 5\*y)))


$${\it expand}\left(\left(3\,x-5\,y\right)\,\left(5\,y+3\,x\right)  \right)=9\,x^2-25\,y^2$$# R.4 Exercise Set

Faktor Trinomial


Nomor 24


\>$&solve(y^2+12\*y+27)


$$\left[ y=-9 , y=-3 \right] $$Nomor 23


\>$&solve(t^2+8\*t+15)


$$\left[ t=-3 , t=-5 \right] $$Factor the difference of squares


Nomor 47


\>$&solve(z^2-81)


$$\left[ z=-9 , z=9 \right] $$Nomor 48


\>$&solve(m^2-4)


$$\left[ m=-2 , m=2 \right] $$Nomor 49


\>$&solve(16\*x^2-9)


$$\left[ x=-\frac{3}{4} , x=\frac{3}{4} \right] $$## R.5 Exercise Set

soal no 36


tentukan nilai y


\>$&solve(y^2-4\*y-45,y)


$$\left[ y=9 , y=-5 \right] $$soal no 38


tentukan nilai y


\>$&solve(t^2+ 6\*t,t)


$$\left[ t=-6 , t=0 \right] $$soal no 41


tentukan nilai x


\>$&solve(x^2+100=20\*x,x)


$$\left[ x=10 \right] $$soal no 42


tentukan nilai y


\>$&solve(y^2+25=10\*y,y)


$$\left[ y=5 \right] $$soal no 45


tentukan nilai y


\>$&solve(3\*y^2 + 8\*y + 4,y)


$$\left[ y=-\frac{2}{3} , y=-2 \right] $$soal no 47


tentukan nilai z


\>$&solve(12\*z^2+z=6,z)


$$\left[ z=-\frac{3}{4} , z=\frac{2}{3} \right] $$soal no 60


tentukan nilai x


\>$&solve(5\*x^2-75=0,x)


$$\left[ x=-\sqrt{15} , x=\sqrt{15} \right] $$## R.6 Exercise Set

Nomor 9


Menyederhanakan


\>$&((x^2)/(x^2-4\*x+4)), $&factor(%)


$$\frac{x^2}{\left(x-2\right)^2}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-021.png](images/SOAL%20PADA%20BUKU%20ALJABAR-021.png)

Nomor 11


Menyederhanakan


\>$&((x^3 - 6\*x^2 + 9\*x)/ (x^3 - 3\*x^2)), $&factor(%)


$$\frac{x-3}{x}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-023.png](images/SOAL%20PADA%20BUKU%20ALJABAR-023.png)

Nomor 14


Menyederhanakan


\>$&((2\*x^2-20\*x+50)/(10\*x^2-30\*x-100)), $&factor(%)


$$\frac{x-5}{5\,\left(x+2\right)}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-025.png](images/SOAL%20PADA%20BUKU%20ALJABAR-025.png)

Nomor 15


Menyederhanakan


\>$&((4-x)/(x^2 +4\*x-32)), $&factor(%)


$$-\frac{1}{x+8}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-027.png](images/SOAL%20PADA%20BUKU%20ALJABAR-027.png)

Nomor 16


Menyederhanakan


\>$&((6-x)/(x^2-36)), $&factor(%)


$$-\frac{1}{x+6}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-029.png](images/SOAL%20PADA%20BUKU%20ALJABAR-029.png)

Nomor 23


\>$&(((m^2-n^2)/(r+s))/((m-n)/r+s)), $&factor(%)


$$\frac{\left(m-n\right)\,\left(n+m\right)\,r}{\left(s+r\right)\,  \left(r\,s-n+m\right)}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-031.png](images/SOAL%20PADA%20BUKU%20ALJABAR-031.png)

Nomor 25


\>$&(((3\*x+12)/(2\*x-8))/(((x+4)^2)/(x-4)^2)), $&factor(%)


$$\frac{3\,\left(x-4\right)}{2\,\left(x+4\right)}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-033.png](images/SOAL%20PADA%20BUKU%20ALJABAR-033.png)

Nomor 28


\>$&(((c^3+8)/(c^2-4)) /((c^2 -2\*c +4)/(c^2-4\*c+4))), $&factor(%) 


$$c-2$$![images/SOAL%20PADA%20BUKU%20ALJABAR-035.png](images/SOAL%20PADA%20BUKU%20ALJABAR-035.png)

# REVIEW 

Multiply


Nomor 73


\>function P(a,b,n,x) &= (a^n - b^n)^x; $&P(a,b,n,x)


$$\left(a^{n}-b^{n}\right)^{x}$$\>$&P(a,b,n,3), $&expand(%)


$$-b^{3\,n}+3\,a^{n}\,b^{2\,n}-3\,a^{2\,n}\,b^{n}+a^{3\,n}$$![images/SOAL%20PADA%20BUKU%20ALJABAR-038.png](images/SOAL%20PADA%20BUKU%20ALJABAR-038.png)

Nomor 71


\>function P(a,n) &= (t^a+t^(-a))^n; $&P(a,n)


$$\left(t^{a}+\frac{1}{t^{a}}\right)^{n}$$\>$&P(a,2), $&expand(%)


$$t^{2\,a}+\frac{1}{t^{2\,a}}+2$$![images/SOAL%20PADA%20BUKU%20ALJABAR-041.png](images/SOAL%20PADA%20BUKU%20ALJABAR-041.png)

Soal 39


\>$&solve(9\*x^2-30\*x+25,x)


$$\left[ x=\frac{5}{3} \right] $$soal nomor 41


\>$&solve(18\*x^2-3\*x+6,x)


$$\left[ x=\frac{1-\sqrt{47}\,i}{12} , x=\frac{\sqrt{47}\,i+1}{12}   \right] $$soal nomor 48


\>$&solve((8-3\*x)=(-7+2\*x),x)


$$\left[ x=3 \right] $$soal nomor 70


\>$& '((x^n+10)\*(x^n-4)) = expand(((x^n+10)\*(x^n-4)))


$$\left(x^{n}-4\right)\,\left(x^{n}+10\right)=x^{2\,n}+6\,x^{n}-40$$soal nomor 71


\>$& '((t^a+t^(-a))^2) = expand(((t^a+t^(-a))^2))


$$\left(t^{a}+\frac{1}{t^{a}}\right)^2=t^{2\,a}+\frac{1}{t^{2\,a}}+2$$soal nomor 72


\>$& '((y^b-z^c)\*(y^b+z^c)) = expand((y^b-z^c)\*(y^b+z^c))


$$\left(y^{b}-z^{c}\right)\,\left(z^{c}+y^{b}\right)=y^{2\,b}-z^{2\,c  }$$soal nomor 73


\>$& '((a^n-b^n)^3) = expand((a^n-b^n)^3)


$$\left(a^{n}-b^{n}\right)^3=-b^{3\,n}+3\,a^{n}\,b^{2\,n}-3\,a^{2\,n}  \,b^{n}+a^{3\,n}$$soal chapter R test nomor 32


\>$& '(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4))) = simplify(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4)))


$$\frac{\left(x^2-25\right)\,\left(x^2+x-6\right)}{\left(x^2-4\,x+4  \right)\,\left(x^2+8\,x+15\right)}={\it simplify}\left(\frac{\left(x  ^2-25\right)\,\left(x^2+x-6\right)}{\left(x^2-4\,x+4\right)\,\left(x  ^2+8\,x+15\right)}\right)$$\>$&solve(((x^2+x-6)/(x^2+8\*x+15))\*((x^2-25)/(x^2-4\*x+4)),x)


$$\left[ x=5 \right] $$soal nomor 33


\>$& '(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))=simplify(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))


$$\frac{x}{x^2-1}-\frac{3}{x^2+4\,x-5}={\it simplify}\left(\frac{x}{x  ^2-1}-\frac{3}{x^2+4\,x-5}\right)$$\>$&solve(((x)/(x^2-1))-((3)/(x^2+4\*x-5)))


$$\left[ x=-3 \right] $$# 2.3 Exercise Set

Cari




dan domain nya !


\>$&gx:=x-3; $&fx:=gx+3; $&fx


$$x$$dengan domainnya


\>$&fx:=x+3; $&gx:=fx-3; $&gx


$$x$$dengan domainnya


\>$&gx:=1/x; $&fx:=4/(1-5\*gx); $&fx


$$\frac{4}{1-\frac{5}{x}}$$dengan domain


\>$&fx:=4/(1-5\*x); $&gx:=1/fx; $&gx


$$\frac{1-5\,x}{4}$$dengan domainnya


Diberikan fungsi


cari


\>$x:=1/3; $&gx:=x^2-2\*x-6; $&fx:=3\*gx+1; $&fx


$$-\frac{56}{3}$$\>$x:=1/2; $&hx:=x^3; $&gx:=hx^2-2\*hx-6; $&gx


$$-\frac{399}{64}$$\>$x:=-2; $&gx:=x^2-2\*x-6; $&gx:=gx^2-2\*gx-6; $&gx


$$-6$$# 3.1 Exercise Set

Use the quadratic formula to find exact solutions


Nomor 37


\>$&solve(x^2-2= 15,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^2-2= 15,x) ...
                        ^

Nomor 39


\>$&solve(5\*m^2+3\*m=2,m)


$$\left[ m=\frac{2}{5} , m=-1 \right] $$Nomor 40


\>$&solve(2\*y^2-3\*y-2=0,y)


$$\left[ y=-\frac{1}{2} , y=2 \right] $$Solve.


Nomor 83


\>$&solve(y^4+4\*y^2-5=0,y)


$$\left[ y=-1 , y=1 , y=-\sqrt{5}\,i , y=\sqrt{5}\,i \right] $$Nomor 84


\>$&solve(y^4-15\*y^2-16=0,y)


$$\left[ y=-i , y=i , y=-4 , y=4 \right] $$# 3.4 Exercise Set Solve

Nomor 1


\>$&solve(1/4+1/5=1/t,t)


$$\left[ t=\frac{20}{9} \right] $$Nomor 2


\>$&solve(1/3-5/6=1/x,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(1/3-5/6=1/x,x) ...
                          ^

Nomor 6


\>$&solve(1/t+1/2\*t+1/3\*t=5,t)


$$\left[ t=\frac{15-\sqrt{195}}{5} , t=\frac{\sqrt{195}+15}{5}   \right] $$Nomor 7


\>$&solve(5/3\*x+2=3/2\*x,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(5/3*x+2=3/2*x,x) ...
                            ^

NOmor 10


\>$&solve(x-12/x=1,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x-12/x=1,x) ...
                       ^

Nomor 18


\>$&solve(3\*y+5/y^2+5\*y +y+4/y+5=y+1/y,y)


$$\left[ y=-\frac{47\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)  }{576\,\left(\frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{  13824}\right)^{\frac{1}{3}}}+\left(\frac{\sqrt{35539}}{128\,3^{  \frac{3}{2}}}-\frac{3905}{13824}\right)^{\frac{1}{3}}\,\left(-\frac{  \sqrt{3}\,i}{2}-\frac{1}{2}\right)-\frac{5}{24} , y=\left(\frac{  \sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}\right)^{  \frac{1}{3}}\,\left(\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)-\frac{  47\,\left(-\frac{\sqrt{3}\,i}{2}-\frac{1}{2}\right)}{576\,\left(  \frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}\right)  ^{\frac{1}{3}}}-\frac{5}{24} , y=\left(\frac{\sqrt{35539}}{128\,3^{  \frac{3}{2}}}-\frac{3905}{13824}\right)^{\frac{1}{3}}-\frac{47}{576  \,\left(\frac{\sqrt{35539}}{128\,3^{\frac{3}{2}}}-\frac{3905}{13824}  \right)^{\frac{1}{3}}}-\frac{5}{24} \right] $$# 3.5 Exercise Set

\>&load(fourier\_elim)


    
                     C:/Program Files/Euler x64/maxima/share/maxima/5.35.1/share/fourier_elim/fourier_elim.lisp
    

Nomor 44


\>$&fourier\_elim([4\*x]\>20,[x]) // 4\*x \> 20


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([4*x]&gt;20,[x]) // 4*x &gt; 20 ...
                                 ^

Nomor 45


\>$&fourier\_elim([x+8]<9,[x])// x+8<9


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([x+8]&lt;9,[x])// x+8&lt;9 ...
                               ^

Nomor 47


\>$&fourier\_elim([x+8]\>= 9,[x])//x+8 \>=9


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([x+8]&gt;= 9,[x])//x+8 &gt;=9 ...
                                 ^

Nomor 52


\>$&fourier\_elim([3\*x+4]<13,[x])//3\*x+4<13


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([3*x+4]&lt;13,[x])//3*x+4&lt;13 ...
                                  ^

Nomor 62


\>$&fourier\_elim([3\*x+5]<0,[x])//3\*x+5<0


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([3*x+5]&lt;0,[x])//3*x+5&lt;0 ...
                                 ^

# Chapter 3 Test

Nomor 8


\>$&solve(3/3\*x+4 + 2/x-1 =2,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(3/3*x+4 + 2/x-1 =2,x) ...
                                 ^

\>$load(fourier\_elim)


Nomor 11


\>$&fourier\_elim([x+4]=7,[x])//x+4=7


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([x+4]=7,[x])//x+4=7 ...
                               ^

Nomor 12


\>$&fourier\_elim([4\*y-3]=5,[x])//4\*y-3=5


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([4*y-3]=5,[x])//4*y-3=5 ...
                                 ^

Solve


Nomor 13


\>$&fourier\_elim([x+3]<=4,[x])//x+3<=4


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([x+3]&lt;=4,[x])//x+3&lt;=4 ...
                                ^

Nomor 15


\>$&fourier\_elim([x+5]\>2,[x])//x+5\>2


    Maxima said:
    Function "$elim" expects a symbol, instead found -2
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;fourier_elim([x+5]&gt;2,[x])//x+5&gt;2 ...
                               ^

Nomor 19


\>$&solve(x^2+4\*x =1,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^2+4*x =1,x) ...
                         ^

# 4.1 Exercise Set

Use the substitution to determine whether 2,3 and -1 are zeros of


Nomor 23


\>function P(x) &= (x^3-9\*x^2+14\*x+24); $&P(x)


$$-48$$\>P(4)


    -48

\>P(5)


    -48

\>P(-2)


    -48

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka 4


Nomor 24


\>function P(x) &= (2\*x^3-3\*x^2+x+6);$&P(x)


$$-24$$\>P(2)


    -24

\>P(3)


    -24

\>P(-1)


    -24

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka -1


Nomor 25


\>function P(x) &= (x^4-6\*x^3+8\*x^2+6\*x-9);$&P(x)


$$75$$\>P(2)


    75

\>P(3)


    75

\>P(-1)


    75

Jadi hasil substitusi yang menghasilkan persamaan mempunyai nilai nol
adalah dengan mensubtsisusi angka 3 dan -1


Nomor 37


\>$&solve(x^4-4\*x^2+3,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^4-4*x^2+3,x) ...
                          ^

Nomor 39


\>$&solve(x^3+3\*x^2-x-3,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^3+3*x^2-x-3,x) ...
                            ^

# 4.3 Exercise Set

Nomor 1


For the function




use long division to determine whether each of the following is a
factor of f(x)


a) x+1


b) x-2


c) x + 5


\>function f(x) &= (x^4-6\*x^3+x^2+24\*x-20);$&f(x)


$$0$$\>$&f(x+1), $&expand(%)


$$0$$![images/SOAL%20PADA%20BUKU%20ALJABAR-072.png](images/SOAL%20PADA%20BUKU%20ALJABAR-072.png)

\>$&f(x-2), $&expand(%)


$$0$$![images/SOAL%20PADA%20BUKU%20ALJABAR-074.png](images/SOAL%20PADA%20BUKU%20ALJABAR-074.png)

\>$&f(x+5), $&expand(%)


$$0$$![images/SOAL%20PADA%20BUKU%20ALJABAR-076.png](images/SOAL%20PADA%20BUKU%20ALJABAR-076.png)

Nomor 23


Use synthetic division to find the function values.




find f(1), f(-2), dan f(3)


\>function f(x) &= (x^3-6\*x^2+11\*x-6);$&f(x)


$$-60$$\>f(1)


    -60

\>f(-2)


    -60

\>f(3)


    -60

Nomor 24




find f(-3),f(-2), dan f(1)


\>function f(x) &= (x^3+7\*x^2-12\*x-3);$&f(x)


$$41$$\>f(-3)


    41

\>f(-2)


    41

\>f(1)


    41

Nomor 25




find f(-1),f(4) dan f(-5)


\>function f(x) &= (x^4-3\*x^3+2\*x+8);$&f(x)


$$44$$\>f(-1)


    44

\>f(4)


    44

\>f(-5)


    44

Factor the polynomial function f(x). Then Solve the equation f(x)=0


Nomor 39


\>fx &= (x^3+4\*x^2+x-6=0); $&fx


$$0=0$$\>$&factor((fx,x^3+4\*x^2+x-6=0))


$$0=0$$\>$&solve(x^3+4\*x^2+x-6=0,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^3+4*x^2+x-6=0,x) ...
                              ^

Nomor 40


\>fx &= (x^3+5\*x^2-2\*x-24=0); $&fx


$$-8=0$$\>$&factor((fx,x^3+5\*x^2-2\*x-24=0))


$$-8=0$$\>$&solve(x^3+5\*x^2-2\*x-24=0,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^3+5*x^2-2*x-24=0,x) ...
                                 ^

# Mid-Chapter Mixed Review

Use synthetic division to find the function values


Nomor 18




find g(-5)


\>function g(x) &= (x^3-9\*x^2+4\*x-10);$&g(x)


$$-62$$\>g(-5)


    -62

Nomor 19




find f(1/2)


\>function f(x) &= (20\*x^2-40\*x);$&f(x)


$$160$$\>f(1/2)


    160

Using synthetic division, determine whether the numbers are zeros of
the polynomial function.


Nomor 22


-1,5; 


\>function f(x) &= (x^6-35\*x^4+259\*x^2-225);$&f(x)


$$315$$\>f(-1.5)


    315

Factor the polynomial function f(x). Then solve the equation f(x) =0.


Nomor 23


\>hx &= (x^3-2\*x^2-55\*x+56=0); $&hx


$$150=0$$\>$&factor((hx,x^3-2\*x^2-55\*x+56=0))


$$150=0$$\>$&solve(x^3-2\*x^2-55\*x+56=0,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^3-2*x^2-55*x+56=0,x) ...
                                  ^

Nomor 24


\>gx &= (x^4-2\*x^3-13\*x^2+14\*x+24=0); $&gx


$$-24=0$$\>$&factor((gx,x^4-2\*x^3-13\*x^2+14\*x+24=0))


$$-24=0$$\>$&solve(x^4-2\*x^3-13\*x^2+14\*x+24=0,x)


    Maxima said:
    solve: all variables must not be numbers.
     -- an error. To debug this try: debugmode(true);
    
    Error in:
     $&amp;solve(x^4-2*x^3-13*x^2+14*x+24=0,x) ...
                                         ^

